#include <iostream>
using namespace std;
double celsiusToFahrenheit(double celsius) {
    return (celsius * 9 / 5) + 32;
}
double fahrenheitToCelsius(double fahrenheit) {
    return (fahrenheit - 32) * 5 / 9;
}

int main() {
    double temperature;
    char choice;
    cout << "Enter the temperature: ";
    cin >> temperature;
    cout << "Enter 'C' to convert to Celsius or 'F' to convert to Fahrenheit: ";
    cin >> choice;
    switch(choice) {
        case 'C':
        case 'c':
            cout << "Temperature in Celsius: " << fahrenheitToCelsius(temperature) << endl;
            break;
        case 'F':
        case 'f':
            cout << "Temperature in Fahrenheit: " << celsiusToFahrenheit(temperature) << endl;
            break;
        default:
            cout << "Invalid choice!";
    }
    return 0;
}
