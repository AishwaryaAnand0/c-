#include <iostream>
using namespace std;
class BankAccount {
private:
    string accountNumber;
    double balance;

public:
    BankAccount(string accNumber, double initialBalance) : accountNumber(accNumber), balance(initialBalance) {
        cout << "Account created with account number: " << accountNumber << endl;
    }
    ~BankAccount() {
        cout << "Account with account number " << accountNumber << " is being destroyed." << endl;
    }
    void displayAccountDetails() {
        cout << "Account Number: " << accountNumber << ", Balance: $" << balance << endl;
    }
};

int main() {
    BankAccount account1("12345", 1000.0);
    BankAccount account2("67890", 2000.0);
    cout << "Account Details:" << endl;
    account1.displayAccountDetails();
    account2.displayAccountDetails();
    return 0;
}
