#include <iostream>
using namespace std;
class Rectangle {
private:
    double length;
    double width;
public:
    Rectangle(double len, double wid) : length(len), width(wid) {
        cout << "A rectangle with length " << length << " and width " << width << " has been created." << endl;
    }
    ~Rectangle() {
        cout << "The rectangle with length " << length << " and width " << width << " has been destroyed." << endl;
    }
    double calculateArea() {
        return length * width;
    }
};

int main() {
    Rectangle rect1(5.0, 3.0);
    Rectangle rect2(4.0, 6.0);
    cout << "Area of Rectangle 1: " << rect1.calculateArea() << endl;
    cout << "Area of Rectangle 2: " << rect2.calculateArea() << endl;

    return 0;
}
