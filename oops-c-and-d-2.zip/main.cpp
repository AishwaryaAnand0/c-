#include <iostream>
using namespace std;
class Car {
private:
    string brand;
    string model;

public:
    Car(string carBrand, string carModel) : brand(carBrand), model(carModel) {
        cout << "A " << brand << " " << model << " car has been created." << endl;
    }
    ~Car() {
        cout << "The " << brand << " " << model << " car has been destroyed." << endl;
    }
    void displayCarDetails() {
        cout << "Car Brand: " << brand << ", Model: " << model << endl;
    }
};

int main() {
    Car car1("Toyota", "Corolla");
    Car car2("Honda", "Civic");
    cout << "Car Details:" << endl;
    car1.displayCarDetails();
    car2.displayCarDetails();

    return 0;
}
