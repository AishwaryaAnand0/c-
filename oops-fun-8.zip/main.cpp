#include <iostream>
using namespace std;

const double PI = 3.14159;
double calculateArea(double radius) {
    return PI * radius * radius;
}
int main() {
    double radius;

    cout << "Enter the radius of the circle: ";
    cin >> radius;

    if (radius < 0) {
        cout << "Radius cannot be negative." << endl;
    } else {
        double area = calculateArea(radius);
        cout << "Area of the circle with radius " << radius << " is: " << area << endl;
    }
    return 0;
}
