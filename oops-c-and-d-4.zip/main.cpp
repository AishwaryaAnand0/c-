#include <iostream>
using namespace std;
class Book {
private:
    string title;
    string author;

public:
    Book(string bookTitle, string bookAuthor) : title(bookTitle), author(bookAuthor) {
        cout << "A book titled '" << title << "' by " << author << " has been created." << endl;
    }
    ~Book() {
        cout << "The book titled '" << title << "' by " << author << " has been destroyed." << endl;
    }
};
int main() {
    Book book1("The Great Gatsby", "F. Scott Fitzgerald");
    Book book2("To Kill a Mockingbird", "Harper Lee");

    return 0;
}
