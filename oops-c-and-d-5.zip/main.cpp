#include <iostream>
using namespace std;
class Student {
private:
    string name;
    int age;
public:
    Student(string studentName, int studentAge) : name(studentName), age(studentAge) {
        cout << "Student named " << name << " with age " << age << " has been enrolled." << endl;
    }
    ~Student() {
        cout << "Student named " << name << " with age " << age << " has been unenrolled." << endl;
    }
};
int main() {
    Student student1("John Doe", 20);
    Student student2("Alice Smith", 22);

    return 0;
}
