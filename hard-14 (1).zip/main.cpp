#include <iostream>
#include <string>
using namespace std;
bool isValidNumber(string s) {
    int i = 0;
    while (i < s.length() && s[i] == ' ') {
        i++;
    }
    int j = s.length() - 1;
    while (j >= 0 && s[j] == ' ') {
        j--;
    }
    if (s[i] == '+' || s[i] == '-') {
        i++;
    }

    bool hasDigit = false;
    bool hasDot = false;
    while (i <= j && (isdigit(s[i]) || s[i] == '.')) {
        if (isdigit(s[i])) {
            hasDigit = true;
        } else if (s[i] == '.') {
            if (hasDot) {
                return false; 
            }
            hasDot = true;
        }
        i++;
    }
    if (!hasDigit || (hasDot && (i == 1 || !isdigit(s[i - 2])))) {
        return false;
    }
    if (i <= j && (s[i] == 'e' || s[i] == 'E')) {
        i++;
        if (i <= j && (s[i] == '+' || s[i] == '-')) {
            i++;
        }
        while (i <= j && isdigit(s[i])) {
            i++;
        }
        if (!isdigit(s[i - 1])) {
            return false;
        }
    }
    return i > j;
}
int main() {
    string s = "0.1"; 
    cout << "Is the string a valid number? " << (isValidNumber(s) ? "Yes" : "No") << endl;
    return 0;
}
