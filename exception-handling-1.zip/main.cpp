#include <iostream>
#include <stdexcept>
class Resource {
public:
    Resource() {
        std::cout << "Resource acquired.\n";
    }
    ~Resource() {
        std::cout << "Resource released.\n";
    }
};
void mightThrowException() {
    Resource res; 
    bool throwException = true;
    if (throwException) {
        throw std::runtime_error("An error occurred.");
    }
}
int main() {
    try {
        mightThrowException();
    } catch (const std::exception& e) {
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }
    return 0;
}
